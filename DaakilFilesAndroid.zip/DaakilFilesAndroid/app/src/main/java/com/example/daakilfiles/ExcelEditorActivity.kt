package com.example.daakilfiles

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import org.apache.poi.ss.usermodel.WorkbookFactory
import java.io.File
import java.io.FileOutputStream

class ExcelEditorActivity : AppCompatActivity() {
    private val bg = Color.rgb(21, 22, 25)
    private val panel = Color.rgb(34, 36, 40)
    private val fg = Color.rgb(241, 243, 246)
    private val muted = Color.rgb(167, 173, 182)
    private var workbook: org.apache.poi.ss.usermodel.Workbook? = null
    private var sourceName = "workbook.xlsx"
    private var selectedSheet = 0
    private val cellInputs = mutableMapOf<Pair<Int, Int>, EditText>()
    private lateinit var sheetTabs: LinearLayout
    private lateinit var grid: LinearLayout
    private lateinit var status: TextView

    private val createSave = registerForActivityResult(ActivityResultContracts.CreateDocument(
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )) { uri -> if (uri != null) saveTo(uri) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setBackgroundColor(bg)
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(TextView(this).apply {
            text = "محرّر Excel"; textSize = 21f; setTextColor(fg)
        }, LinearLayout.LayoutParams(0, dp(48), 1f))
        val save = Button(this).apply {
            text = "حفظ نسخة"; isAllCaps = false
            setOnClickListener { syncEdits(); createSave.launch(safeFilename(sourceName)) }
        }
        top.addView(save)
        root.addView(top)
        status = TextView(this).apply { textSize = 12f; setTextColor(muted); text = "جارٍ تحميل الملف…" }
        root.addView(status, LinearLayout.LayoutParams(-1, dp(30)))
        sheetTabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val tabsScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(sheetTabs) }
        root.addView(tabsScroll, LinearLayout.LayoutParams(-1, dp(48)))
        grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val horizontal = HorizontalScrollView(this).apply { addView(grid) }
        val vertical = ScrollView(this).apply { addView(horizontal) }
        root.addView(vertical, LinearLayout.LayoutParams(-1, 0, 1f))
        val tip = TextView(this).apply {
            text = "اضغط على الخلية لتعديلها. احفظ نسخة للحفاظ على الملف الأصلي."
            textSize = 12f; setTextColor(muted)
        }
        root.addView(tip, LinearLayout.LayoutParams(-1, dp(34)))
        setContentView(root)
        loadWorkbook()
    }

    private fun loadWorkbook() {
        try {
            val uri = intent.data ?: error("لم يتم اختيار ملف")
            sourceName = queryName(uri) ?: "workbook.xlsx"
            contentResolver.openInputStream(uri).use { input ->
                workbook = WorkbookFactory.create(input ?: error("تعذّر قراءة الملف"))
            }
            buildTabs()
            renderSheet(0)
        } catch (e: Exception) {
            status.text = "تعذّر فتح الملف"
            Toast.makeText(this, "تعذّر فتح Excel: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun buildTabs() {
        sheetTabs.removeAllViews()
        val wb = workbook ?: return
        for (i in 0 until wb.numberOfSheets) {
            val b = Button(this).apply {
                text = wb.getSheetName(i); isAllCaps = false
                setOnClickListener { syncEdits(); renderSheet(i) }
            }
            sheetTabs.addView(b, LinearLayout.LayoutParams(-2, dp(44)))
        }
    }

    private fun renderSheet(index: Int) {
        val wb = workbook ?: return
        selectedSheet = index
        cellInputs.clear()
        grid.removeAllViews()
        val sheet = wb.getSheetAt(index)
        val lastRow = (sheet.lastRowNum + 1).coerceAtMost(101)
        val lastCol = (0..sheet.lastRowNum).maxOfOrNull { r ->
            sheet.getRow(r)?.lastCellNum?.toInt()?.coerceAtLeast(0) ?: 0
        }?.coerceAtMost(26) ?: 0
        if (lastRow == 0 || lastCol == 0) {
            status.text = "الورقة فارغة"
            return
        }
        status.text = "${sheet.sheetName} • عرض أول 100 صف و26 عمودًا كحد أقصى"
        for (r in 0 until lastRow) {
            val rowLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val rowNum = TextView(this).apply {
                text = (r + 1).toString(); gravity = Gravity.CENTER
                setTextColor(muted); setBackgroundColor(panel); textSize = 12f
            }
            rowLayout.addView(rowNum, LinearLayout.LayoutParams(dp(42), dp(48)))
            for (c in 0 until lastCol) {
                val value = sheet.getRow(r)?.getCell(c)?.toString() ?: ""
                val edit = EditText(this).apply {
                    setText(value); textSize = 13f; setTextColor(fg)
                    setHintTextColor(muted); setSingleLine(true)
                    setPadding(dp(8), 0, dp(8), 0)
                    setBackgroundColor(if ((r + c) % 2 == 0) panel else Color.rgb(27, 29, 32))
                    hint = "${columnName(c)}${r + 1}"
                }
                cellInputs[Pair(r, c)] = edit
                rowLayout.addView(edit, LinearLayout.LayoutParams(dp(132), dp(48)))
            }
            grid.addView(rowLayout)
        }
    }

    private fun syncEdits() {
        val sheet = workbook?.getSheetAt(selectedSheet) ?: return
        for ((coord, input) in cellInputs) {
            val (r, c) = coord
            val row = sheet.getRow(r) ?: sheet.createRow(r)
            val cell = row.getCell(c) ?: row.createCell(c)
            val value = input.text.toString()
            if (value.isBlank()) cell.setBlank()
            else {
                val n = value.toDoubleOrNull()
                if (n != null) cell.setCellValue(n) else cell.setCellValue(value)
            }
        }
    }

    private fun saveTo(uri: Uri) {
        try {
            contentResolver.openOutputStream(uri, "wt").use { out ->
                workbook?.write(out ?: error("تعذّر إنشاء ملف الحفظ"))
            }
            Toast.makeText(this, "تم حفظ النسخة بنجاح", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "فشل الحفظ: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun queryName(uri: Uri): String? {
        return contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    }
    private fun safeFilename(name: String): String {
        val base = name.substringBeforeLast('.', name)
        return "${base}_edited.xlsx"
    }
    private fun columnName(col: Int): String {
        var n = col + 1; var result = ""
        while (n > 0) { val rem = (n - 1) % 26; result = ('A'.code + rem).toChar() + result; n = (n - 1) / 26 }
        return result
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
