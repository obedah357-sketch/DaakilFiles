package com.example.daakilfiles

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val bg = Color.rgb(21, 22, 25)
    private val panel = Color.rgb(34, 36, 40)
    private val text = Color.rgb(241, 243, 246)
    private val muted = Color.rgb(167, 173, 182)

    private val openPdf = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { launchViewer(PdfViewerActivity::class.java, it) }
    }
    private val openExcel = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { launchViewer(ExcelEditorActivity::class.java, it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 17, 19)
        window.navigationBarColor = Color.rgb(16, 17, 19)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(22))
            setBackgroundColor(bg)
        }
        val brand = TextView(this).apply {
            text = "دَخيل"
            textSize = 32f
            setTextColor(text)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val subtitle = TextView(this).apply {
            text = "ملفاتك، بمكان واحد"
            textSize = 15f
            setTextColor(muted)
            gravity = Gravity.CENTER
        }
        root.addView(brand, lp(-1, -2))
        root.addView(subtitle, LinearLayout.LayoutParams(-1, dp(34)))
        val spacer = View(this)
        root.addView(spacer, LinearLayout.LayoutParams(1, dp(24)))

        root.addView(makeCard(
            "📄  قارئ PDF",
            "افتح مستندات PDF وتصفّح الصفحات",
            "اختيار ملف PDF"
        ) { openPdf.launch(arrayOf("application/pdf")) }, lp(-1, dp(170)))

        val gap = View(this)
        root.addView(gap, LinearLayout.LayoutParams(1, dp(16)))
        root.addView(makeCard(
            "📊  محرّر Excel",
            "اعرض الخلايا وعدّل محتواها ثم احفظ نسخة",
            "اختيار ملف Excel"
        ) { openExcel.launch(arrayOf(
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "application/vnd.ms-excel"
        )) }, lp(-1, dp(170)))

        val note = TextView(this).apply {
            text = "خصوصية أولاً • تُفتح الملفات التي تختارها فقط"
            textSize = 12f
            setTextColor(muted)
            gravity = Gravity.CENTER
        }
        root.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))
        root.addView(note, lp(-1, dp(36)))
        setContentView(root)
    }

    private fun makeCard(title: String, description: String, buttonText: String, action: () -> Unit): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(14))
            setBackgroundColor(panel)
        }
        card.addView(TextView(this).apply {
            text = title; textSize = 21f; setTextColor(text)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }, lp(-1, dp(34)))
        card.addView(TextView(this).apply {
            text = description; textSize = 14f; setTextColor(muted)
        }, lp(-1, dp(36)))
        val button = Button(this).apply {
            text = buttonText
            isAllCaps = false
            setTextColor(text)
            setBackgroundColor(Color.rgb(67, 71, 78))
            setOnClickListener { action() }
        }
        card.addView(button, lp(-1, dp(48)))
        return card
    }

    private fun launchViewer(cls: Class<*>, uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) { }
        startActivity(Intent(this, cls).setData(uri))
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)
}
