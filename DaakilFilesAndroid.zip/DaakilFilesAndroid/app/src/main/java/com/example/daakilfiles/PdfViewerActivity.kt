package com.example.daakilfiles

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.Gravity
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class PdfViewerActivity : AppCompatActivity() {
    private var renderer: PdfRenderer? = null
    private var descriptor: ParcelFileDescriptor? = null
    private var pageIndex = 0
    private lateinit var image: ImageView
    private lateinit var pageLabel: TextView
    private lateinit var prev: Button
    private lateinit var next: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 17, 19)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.rgb(21, 22, 25))
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply {
            text = "قارئ PDF"; textSize = 20f; setTextColor(Color.WHITE)
        }
        top.addView(title, LinearLayout.LayoutParams(0, dp(44), 1f))
        pageLabel = TextView(this).apply { setTextColor(Color.LTGRAY); textSize = 14f }
        top.addView(pageLabel)
        root.addView(top)
        image = ImageView(this).apply { adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER }
        val scroll = ScrollView(this).apply { addView(image) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        prev = Button(this).apply { text = "السابق"; isAllCaps = false; setOnClickListener { showPage(pageIndex - 1) } }
        next = Button(this).apply { text = "التالي"; isAllCaps = false; setOnClickListener { showPage(pageIndex + 1) } }
        controls.addView(prev, LinearLayout.LayoutParams(0, dp(48), 1f))
        controls.addView(next, LinearLayout.LayoutParams(0, dp(48), 1f))
        root.addView(controls)
        setContentView(root)

        try {
            val uri = intent.data ?: error("لم يتم اختيار ملف")
            descriptor = contentResolver.openFileDescriptor(uri, "r") ?: error("تعذّر فتح الملف")
            renderer = PdfRenderer(descriptor!!)
            showPage(0)
        } catch (e: Exception) {
            Toast.makeText(this, "تعذّر فتح PDF: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun showPage(index: Int) {
        val r = renderer ?: return
        if (index !in 0 until r.pageCount) return
        pageIndex = index
        val page = r.openPage(index)
        val width = (page.width * 1.5f).toInt().coerceAtLeast(1)
        val height = (page.height * 1.5f).toInt().coerceAtLeast(1)
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        bitmap.eraseColor(Color.WHITE)
        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        page.close()
        image.setImageBitmap(bitmap)
        pageLabel.text = "${index + 1} / ${r.pageCount}"
        prev.isEnabled = index > 0
        next.isEnabled = index < r.pageCount - 1
    }

    override fun onDestroy() {
        renderer?.close()
        descriptor?.close()
        super.onDestroy()
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
